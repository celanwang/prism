# P2-T1 权重量化报告草稿（待规划层终审）

CPU 实测：Apple M4 Max；设备 CPU；单线程。
预热 3 次，重复 30 次；两个相反顺序批次；单位 ms。
实现通过不表示精度可接受；本任务不设精度合格阈值。

## 精度与精确载荷簿记

token 一致率只计生成后缀；首分歧为生成后缀零基索引。logits 对比 reference_logits.npz。

| 方案 | within 一致率/首分歧 | rollover 一致率/首分歧 | logits max/MSE | 随机一致率 | 模型 bytes | 压缩比 |
| --- | --- | --- | --- | --- | --- | --- |
| fp32 | 1.000000/None | 1.000000/None | 9.53674316e-06/1.94212968e-12 | 1.000000 | 1914880 | 1.000000× |
| int8 | 1.000000/None | 1.000000/None | 0.0651092529/0.000232012259 | 1.000000 | 744448 | 2.572215× |
| int4 | 0.968750/24 | 0.562500/9 | 0.57213974/0.0251380081 | 0.562500 | 587776 | 3.257840× |

随机 prompts：种子 42，8 个，长度 12，生成 16；对比 cached fp32。

精确簿记（包含 padding 和 fp32 scales，零点为隐式 0；不计 Python 元数据）：

```json
{
  "fp32": {
    "total_bytes": 1914880,
    "compression_ratio": 1.0
  },
  "int8": {
    "fp32_baseline_bytes": 1914880,
    "linear_fp32_bytes": 1572864,
    "retained_fp32_bytes": 342016,
    "integer_bytes_including_padding": 393216,
    "scale_bytes": 9216,
    "zero_point_bytes": 0,
    "total_bytes": 744448,
    "compression_ratio": 2.5722145804676755,
    "linear_compression_ratio": 3.9083969465648853
  },
  "int4": {
    "fp32_baseline_bytes": 1914880,
    "linear_fp32_bytes": 1572864,
    "retained_fp32_bytes": 342016,
    "integer_bytes_including_padding": 196608,
    "scale_bytes": 49152,
    "zero_point_bytes": 0,
    "total_bytes": 587776,
    "compression_ratio": 3.2578397212543555,
    "linear_compression_ratio": 6.4
  }
}
```

## 时延与峰值旁证

prefill 为整段提示；decode 为固定 fp32 前缀下 32 个 cached 步骤，排除 prefill。
每条记录含完整 config hash、env 指纹及原始 samples。

| batch | 方案 | 阶段 | 成分 | p50 | p95 | p99 | traced peak bytes | RSS bytes | config hash | env 指纹 | run |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | fp32 | prefill | full | 0.722688 | 0.740015 | 0.756814 | 251575 | 88293376 | 0376384da6c2830e3e4a49145bcf8bf60cdddb094bd8eee5b33b4bcb2e2eb337 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-fp32-prefill-full |
| 1 | fp32 | prefill | dequantize | 0.000417 | 0.000482 | 0.000529 | 392 | 99483648 | 0885ab7f1625ff40426efdf4767c41a41602f33e351261f65c0178125fed1c19 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-fp32-prefill-dequantize |
| 1 | fp32 | prefill | matmul_bias | 0.075292 | 0.078527 | 0.080181 | 117560 | 99483648 | 0f1d22a99df935dd3d24aed70a7d470660c51b50e04aaef678abd02366ba1bfa | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-fp32-prefill-matmul_bias |
| 1 | fp32 | decode | full | 16.792813 | 16.900735 | 16.931927 | 221744 | 99581952 | eb0eaa73c6bd5ac9fa7958b9e8ad8a6382208a826978190ea4243617954d8f25 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-fp32-decode-full |
| 1 | fp32 | decode | dequantize | 0.000459 | 0.000607 | 0.000684 | 392 | 99581952 | 05d18de827722fcf7d5f00a480f019a5b6942bdf3f8e2eb864b8aaef2e981c7d | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-fp32-decode-dequantize |
| 1 | fp32 | decode | matmul_bias | 1.096312 | 1.114069 | 1.117212 | 6456 | 99598336 | edd5fa04cabae094454f86c5b598d2b4ad07f7dd03438189697386cf73b4fe59 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-fp32-decode-matmul_bias |
| 1 | int8 | prefill | full | 0.883605 | 0.904367 | 0.922313 | 701442 | 101122048 | f8c57153af0bc07985fdb281f79e4e1e36a01f037f27c6ac19fe69e4e1616bec | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int8-prefill-full |
| 1 | int8 | prefill | dequantize | 0.168687 | 0.172360 | 0.172949 | 558760 | 101122048 | ade1e4afcc51853dfe5b81784afec2c9d4c0968399342972dbd9c835a34673c1 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int8-prefill-dequantize |
| 1 | int8 | prefill | matmul_bias | 0.075416 | 0.077577 | 0.080183 | 117560 | 101122048 | 2a756a3204e5333dc5cd7fe513d86c33e3c4b2b72a6ea901e3d11cae2bfdeecb | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int8-prefill-matmul_bias |
| 1 | int8 | decode | full | 23.649104 | 23.969790 | 24.004650 | 774149 | 102498304 | 34a235933814979b96c8e1f8d5000aab152ade7f509ec780b7d3285f8a993152 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int8-decode-full |
| 1 | int8 | decode | dequantize | 5.337687 | 6.520950 | 6.530077 | 558760 | 102498304 | c7ed08d69b9b3a1b2057b9bcc80d69f2ac95b82f10287d08cdee911a5facda58 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int8-decode-dequantize |
| 1 | int8 | decode | matmul_bias | 1.116646 | 1.135154 | 1.148108 | 6456 | 102498304 | da33af3321331b15a425fd60c2f9fea5025b5d51d632f0c182401031800c633c | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int8-decode-matmul_bias |
| 1 | int4 | prefill | full | 3.594146 | 3.800650 | 3.822099 | 1061063 | 104349696 | 8dd095c7fb4f23a0f330602e574235b24001a4c174c5bb57474f4db1c7cfbeff | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int4-prefill-full |
| 1 | int4 | prefill | dequantize | 2.777208 | 2.831525 | 2.847756 | 918576 | 104349696 | 3cdc2df97c23922246b50f9c04a47c29fb7d7a18900cdab81078b547180b4afc | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int4-prefill-dequantize |
| 1 | int4 | prefill | matmul_bias | 0.123229 | 0.149917 | 0.165027 | 117560 | 104349696 | 45d8be1b161d16ae0786a8b7208e7e32dedff709788927a027bc7cdf189ad8b7 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int4-prefill-matmul_bias |
| 1 | int4 | decode | full | 109.195625 | 112.063111 | 112.438198 | 1133923 | 106676224 | 0793bf9c0be34fc47d43e40b12dd1e6823a19c2384fc7e5a173ecd6926de68f1 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int4-decode-full |
| 1 | int4 | decode | dequantize | 90.467771 | 91.550306 | 91.771562 | 918576 | 106676224 | 4b25de89f8f76b3a0c81416f0cf234ef09cca928148df9b60b43849205c2c3b0 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int4-decode-dequantize |
| 1 | int4 | decode | matmul_bias | 1.117438 | 1.135045 | 1.139238 | 6456 | 106676224 | 94881c9fef1fccac04a454d42ad9ad632052c4a92c99c561c4ac55a6590842e3 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b1-int4-decode-matmul_bias |
| 2 | int4 | prefill | full | 3.668145 | 3.724775 | 3.739299 | 1061318 | 106692608 | ec67bfc029d16b556007659b2fd6e956d3c500c5e4f35f2b2b5916a380f5bcce | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int4-prefill-full |
| 2 | int4 | prefill | dequantize | 2.865646 | 2.899419 | 2.954901 | 918576 | 106692608 | 5a2f64fe8cec57785432151ca8a35e2798d665d63f60b753e24d827b6b943c60 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int4-prefill-dequantize |
| 2 | int4 | prefill | matmul_bias | 0.147000 | 0.163377 | 0.179706 | 117560 | 106708992 | 6009a4559cfa2b78ab89c201c1060ecacbc263126e50cd286a0f6774cc3ee6c4 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int4-prefill-matmul_bias |
| 2 | int4 | decode | full | 109.541938 | 112.794079 | 121.242466 | 1133923 | 107167744 | d517d58bdde8f1ef80569499bea3444c340dd09846988b0dec0d615c8066f39e | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int4-decode-full |
| 2 | int4 | decode | dequantize | 93.839979 | 99.409087 | 101.167970 | 918576 | 107167744 | f9dc8be8751404ab5ccf21ff0c4a23d2e27f84b29b606d23d40b8ea02902b749 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int4-decode-dequantize |
| 2 | int4 | decode | matmul_bias | 1.071271 | 1.078342 | 1.078713 | 6456 | 107167744 | b5c6ccbdae592e7f69fb4ea266f2ea89ea43844a435a9c823ac86abb2ae743d3 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int4-decode-matmul_bias |
| 2 | int8 | prefill | full | 0.982792 | 1.011925 | 1.036910 | 701391 | 107216896 | 62ff91fe7c563bdfca49c53961e166d37b3b6b5c57a09cd326c38780b08073a9 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int8-prefill-full |
| 2 | int8 | prefill | dequantize | 0.198833 | 0.223663 | 0.263245 | 558760 | 107216896 | 4cc73777f7a22a25859165a2c6bb8af89bbf72f7207e78a90e8febbf8f795ede | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int8-prefill-dequantize |
| 2 | int8 | prefill | matmul_bias | 0.144750 | 0.160579 | 0.163836 | 117560 | 107216896 | a0f3d9171a81b3c0e189ff87e73d35f2d0f68d930014547ba05e753265d9da64 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int8-prefill-matmul_bias |
| 2 | int8 | decode | full | 23.984875 | 24.464052 | 24.583872 | 774149 | 107757568 | 245d434e3458af7e88d662339e09962dcf521fe6ae9be308055f32fe5a7bd282 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int8-decode-full |
| 2 | int8 | decode | dequantize | 6.944062 | 7.219631 | 7.227194 | 558760 | 107757568 | 933ce9b043d2f2492130b5039ca661ed29db6352efd35db2eae1b1c0b22d0b72 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int8-decode-dequantize |
| 2 | int8 | decode | matmul_bias | 1.139333 | 1.148789 | 1.153129 | 6456 | 107757568 | a37c533bad3f1f5bccf9b84a355ec1e10b5fb22ee27d053f3c3642d037262502 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-int8-decode-matmul_bias |
| 2 | fp32 | prefill | full | 0.794625 | 0.837443 | 0.862196 | 250879 | 107773952 | 4bb35a2a2571a1ff1c1884f59bbd6e489b9e64ade8a4fa6a5b75adc60fb0cf34 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-fp32-prefill-full |
| 2 | fp32 | prefill | dequantize | 0.000458 | 0.000523 | 0.000601 | 392 | 107773952 | be7960cdbc841521e6bdd944e85e2215f05b5a3e562c043d2961b56bc9f432a5 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-fp32-prefill-dequantize |
| 2 | fp32 | prefill | matmul_bias | 0.121125 | 0.134684 | 0.138138 | 117560 | 107773952 | e3c9f5334f8209c33812c26f200d33d5be4a5a2dd87d9a646a4bcff36f2f6b74 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-fp32-prefill-matmul_bias |
| 2 | fp32 | decode | full | 16.788854 | 17.276496 | 17.438786 | 221693 | 108396544 | 791930d21446cd6d0d5f8797ae91406c7f53b9c5330732204f5bf8de7427ab5c | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-fp32-decode-full |
| 2 | fp32 | decode | dequantize | 0.000417 | 0.000523 | 0.000571 | 392 | 108396544 | 67703d1e20df995c4ce986c9cfd17b7975d8c2564e7e242db406da1b4b8178d5 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-fp32-decode-dequantize |
| 2 | fp32 | decode | matmul_bias | 1.079687 | 1.084425 | 1.088524 | 6456 | 108412928 | 15de8993c10ff0e03aca4045e034b707f9ad309de8034f0603fc32ddf3ae0a27 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-125541578886-b2-fp32-decode-matmul_bias |

## 反量化与矩阵乘占比（独立探针估算）

来自实际 Linear 输入的重放；分母为完整回路 mean。独立测量并不保证相加为 100%，matmul 含 bias，输出头仍属 fp32 且不计入此 Linear 探针。

| batch | 方案 | 阶段 | 反量化/full mean | matmul+bias/full mean |
| --- | --- | --- | --- | --- |
| 1 | fp32 | prefill | 0 (无反量化) | 10.43% |
| 1 | fp32 | decode | 0 (无反量化) | 6.52% |
| 1 | int8 | prefill | 18.90% | 8.54% |
| 1 | int8 | decode | 24.81% | 4.71% |
| 1 | int4 | prefill | 76.89% | 3.52% |
| 1 | int4 | decode | 82.89% | 1.02% |
| 2 | int4 | prefill | 78.17% | 4.03% |
| 2 | int4 | decode | 85.46% | 0.97% |
| 2 | int8 | prefill | 20.54% | 14.99% |
| 2 | int8 | decode | 28.59% | 4.75% |
| 2 | fp32 | prefill | 0 (无反量化) | 15.34% |
| 2 | fp32 | decode | 0 (无反量化) | 6.45% |

## T4 经验阈值

阈值 0.092584 ms，来源 results/p0/calibration.md；低于该阈值的差异不作为收益证据。超过阈值不自动证明显著性。

```json
[
  {
    "batch": 1,
    "phase": "prefill",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -0.16091650000000002,
    "p50_speedup": 0.8178862828335528,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 1,
    "phase": "prefill",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -2.8714585,
    "p50_speedup": 0.20107360676589003,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 1,
    "phase": "decode",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -6.856291500000001,
    "p50_speedup": 0.7100823988934211,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 1,
    "phase": "decode",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -92.40281250000001,
    "p50_speedup": 0.15378649556701562,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "prefill",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -0.18816749999999993,
    "p50_speedup": 0.8085378187856638,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "prefill",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -2.8735209999999993,
    "p50_speedup": 0.2166284025538246,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "decode",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -7.196020500000003,
    "p50_speedup": 0.6999767353384163,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "decode",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -92.75308349999999,
    "p50_speedup": 0.15326417266782336,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  }
]
```

## 实现、诊断和边界

0.5M small model, CPU, fp32 activations/KV/embeddings/tied head; weight-only. Dequantize on every Linear, then fp32 matmul: no native integer MAC acceleration. No accuracy acceptance threshold. Implementation passed does not mean acceptable accuracy. Decode uses a fixed fp32 teacher-forced continuation and immutable prefill cache, no rollover; full decoding includes K/V concatenations. Components replay captured actual Linear inputs; dequantize and matmul+bias are separately measured probes, not additive causal attribution. Persistent payload ledger excludes Python metadata and transient buffers; tied head counted once. All comparison models and probe buffers coexist; tracemalloc peaks are incremental, miss native allocations; RSS is process lifetime high-water mark, neither proves model compression. Counterbalanced single-process orders, no confidence intervals. T4 floor is a historical heuristic.

INT8 每输出通道 [-127,127]；INT4 按输入列分组 [-7,7]，真 nibble 打包，低 nibble 在先；fp32 scales，ties-to-even，尾组补 0。embedding 与共享头保留 fp32。
逐层权重误差、随机逐用例结果、cached/非 cached 的 teacher-forced 前缀定位见首个 run 的 comparison.json。

复现：`uv run --locked python scripts/quant_bench.py`；`--check` 校验并执行完整配方，仅打印 JSON，不写盘。
