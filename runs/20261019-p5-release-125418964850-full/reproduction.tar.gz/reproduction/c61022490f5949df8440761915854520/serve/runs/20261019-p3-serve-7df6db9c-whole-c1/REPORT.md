# P3-T1 HTTP 服务与部署等价性

硬件/设备：Apple M4 Max / CPU / 1 native thread；每个 grid point 预热 2 轮、重复 5 轮。
实测：本机 loopback、同进程客户端与服务、小模型；不代表生产性能。
分位数均用 NumPy linear；请求级只统计成功请求（含排队），拒绝单独记录。
Measurement 是完整一轮耗时，不能解读为单请求时延。

硬门槛：fixture within_window/window_rollover + 固定种子随机 prompt，
HTTP 整包 == SSE done/逐 token 重建 == 独立本地 generate(use_cache=True)。
完整序列见 equivalence.json；事件门控真流式验证见 tests/test_serve.py。

| 模式 | C | 成功/请求 | 429 | 请求 E2E p50/p95/p99 ms | 等待 p50/p95/p99 ms | 整轮 p50/p95/p99 ms |
| --- | --- | --- | --- | --- | --- | --- |
| 实测 whole | 1 | 160/160 | 0 | 8.563/9.874/10.002 | 0.028/0.034/0.081 | 262.224/263.700/263.800 |
| 模拟 whole | 1 | 118/172 | 54 | 22.965/33.352/35.596 | 12.393/22.368/24.344 | 无 |
| 实测 whole | 2 | 160/160 | 0 | 11.750/18.288/18.693 | 2.480/8.660/8.904 | 253.597/254.823/255.044 |
| 模拟 whole | 2 | 114/172 | 58 | 23.873/33.568/35.915 | 12.879/23.078/25.173 | 无 |
| 实测 whole | 4 | 120/160 | 40 | 17.990/26.333/27.492 | 8.306/17.560/17.971 | 193.109/193.971/194.039 |
| 模拟 whole | 4 | 93/172 | 79 | 24.976/33.663/35.714 | 14.868/22.986/23.590 | 无 |
| 实测 whole | 8 | 60/160 | 100 | 19.368/29.035/29.589 | 9.178/17.917/19.176 | 105.602/110.817/111.531 |
| 模拟 whole | 8 | 53/172 | 119 | 27.809/33.856/34.632 | 17.726/23.449/24.054 | 无 |
| 实测 stream | 1 | 160/160 | 0 | 9.427/11.090/11.165 | 0.055/0.085/0.175 | 292.580/293.403/293.488 |
| 模拟 stream | 1 | 124/172 | 48 | 21.132/31.653/34.134 | 10.463/19.978/23.944 | 无 |
| 实测 stream | 2 | 160/160 | 0 | 13.652/21.233/21.596 | 3.092/10.248/10.549 | 293.849/296.514/297.005 |
| 模拟 stream | 2 | 126/172 | 46 | 21.176/31.498/35.998 | 11.032/19.923/23.858 | 无 |
| 实测 stream | 4 | 119/160 | 41 | 20.117/30.058/31.791 | 9.134/19.773/20.777 | 221.381/227.969/228.878 |
| 模拟 stream | 4 | 104/172 | 68 | 23.710/33.194/35.364 | 13.204/23.032/23.659 | 无 |
| 实测 stream | 8 | 60/160 | 100 | 22.499/33.356/34.175 | 10.698/21.255/22.159 | 118.622/128.468/129.493 |
| 模拟 stream | 8 | 60/172 | 112 | 28.012/32.156/34.725 | 16.337/22.377/24.126 | 无 |

T3 同名义参数：batch_size=1、batch_timeout_ms=0、相同 Q 与长度分布。
模拟的 offered rate 为实测每轮请求数/整轮时长；模拟 Poisson 到达，实测固定序列分波闭环。
T3 保留 P0 无缓存服务成本代理（来源、哈希、近似均在模拟 config.json）；
未标定 HTTP/cached 成本，未建模 socket/线程/客户端与 tracemalloc 开销，
长度与服务耗时相关性也不同。仅做分布对照，不比较逐请求轨迹或声称拟合精度。
高并发拒绝数受 OS/线程调度影响；固定种子固定的是请求序列和并发模式。
等待仅含服务推理队列；TTFT、拒绝 E2E 和每请求明细见 summary.json/requests.json。

- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c1`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `7e01398714811cbedafe57b36e762da04ff7dcb2a8c781fd9c9d76461b0ef040`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c1-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c2`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `aa61597cba9c65370217bae35637340c35704d7981dbbb0d871cad7db6252e42`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c2-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c4`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `59ea707dce255fff770f99b1fbeda94ed7a03f47bcde86f10466949df979778a`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c4-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c8`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `9ee73d31efb3beb286ae4e0ae79fc03429b25621f5d2ed699859aa4f944de352`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-whole-c8-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c1`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `719017239c5ce4d69dd11e15916c1fbcdf503789956c593e8ab97255d408126e`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c1-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c2`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `ccc372d814c382a5f2a7a79e29739683b39bf18c9517a7bffbfbecd5e204a8ba`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c2-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c4`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `a41a41c2b330c741da6f5ef5f80ed9ecb26fc6b22b357a53dc311c80188e5214`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c4-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c8`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `70ad66ee73bef2f80471da3e26ac57fe89c2660176fff028fade599ec1c5f2f6`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-ez_6c2pb/repo/runs/.reproduce/c61022490f5949df8440761915854520/serve/runs/20261019-p3-serve-7df6db9c-stream-c8-sim`。
