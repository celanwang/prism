# P3-T1 HTTP 服务与部署等价性

硬件/设备：Apple M4 Max / CPU / 1 native thread；每个 grid point 预热 2 轮、重复 5 轮。
实测：本机 loopback、同进程客户端与服务、小模型；不代表生产性能。
分位数均用 NumPy linear；请求级只统计成功请求（含排队），拒绝单独记录。
Measurement 是完整一轮耗时，不能解读为单请求时延。

硬门槛：fixture within_window/window_rollover + 固定种子随机 prompt，
HTTP 整包 == SSE done/逐 token 重建 == 独立本地 generate(use_cache=True)。
完整序列见 equivalence.json；事件门控真流式验证见 tests/test_serve.py。

| 模式 | C | 成功/请求 | 429 | 请求 E2E p50/p95/p99 ms | 等待 p50/p95/p99 ms | 整轮 p50/p95/p99 ms |
| --- | --- | --- | --- | --- | --- | --- |
| 实测 whole | 1 | 160/160 | 0 | 8.743/10.269/10.732 | 0.028/0.053/0.075 | 268.164/275.912/277.012 |
| 模拟 whole | 1 | 119/172 | 53 | 21.902/33.400/35.181 | 11.567/21.751/23.688 | 无 |
| 实测 whole | 2 | 160/160 | 0 | 12.334/19.081/19.964 | 2.639/9.071/9.573 | 270.180/272.644/272.757 |
| 模拟 whole | 2 | 119/172 | 53 | 21.949/33.014/34.949 | 11.574/21.751/23.194 | 无 |
| 实测 whole | 4 | 120/160 | 40 | 17.266/27.550/29.503 | 8.000/17.723/18.400 | 199.946/206.362/206.416 |
| 模拟 whole | 4 | 96/172 | 76 | 26.598/33.369/35.472 | 15.277/22.648/24.628 | 无 |
| 实测 whole | 8 | 60/160 | 100 | 20.907/31.354/33.243 | 11.240/20.930/22.234 | 114.974/125.881/126.746 |
| 模拟 whole | 8 | 57/172 | 115 | 28.369/35.487/38.041 | 16.714/23.799/26.516 | 无 |
| 实测 stream | 1 | 160/160 | 0 | 10.474/12.305/13.047 | 0.081/0.233/0.264 | 329.504/334.395/334.564 |
| 模拟 stream | 1 | 135/172 | 37 | 20.014/30.786/34.642 | 10.436/20.254/25.439 | 无 |
| 实测 stream | 2 | 160/160 | 0 | 15.437/23.061/23.898 | 3.304/11.169/11.867 | 329.784/334.265/334.885 |
| 模拟 stream | 2 | 135/172 | 37 | 20.013/30.719/34.568 | 10.387/20.246/25.400 | 无 |
| 实测 stream | 4 | 118/160 | 42 | 21.937/33.592/35.987 | 10.038/20.926/22.723 | 244.577/253.882/255.317 |
| 模拟 stream | 4 | 110/172 | 62 | 23.952/33.574/34.851 | 12.757/22.034/24.135 | 无 |
| 实测 stream | 8 | 60/160 | 100 | 23.010/35.065/35.790 | 10.950/23.265/23.563 | 132.953/133.650/133.681 |
| 模拟 stream | 8 | 65/172 | 107 | 27.519/32.474/34.115 | 16.364/22.822/24.520 | 无 |

T3 同名义参数：batch_size=1、batch_timeout_ms=0、相同 Q 与长度分布。
模拟的 offered rate 为实测每轮请求数/整轮时长；模拟 Poisson 到达，实测固定序列分波闭环。
T3 保留 P0 无缓存服务成本代理（来源、哈希、近似均在模拟 config.json）；
未标定 HTTP/cached 成本，未建模 socket/线程/客户端与 tracemalloc 开销，
长度与服务耗时相关性也不同。仅做分布对照，不比较逐请求轨迹或声称拟合精度。
高并发拒绝数受 OS/线程调度影响；固定种子固定的是请求序列和并发模式。
等待仅含服务推理队列；TTFT、拒绝 E2E 和每请求明细见 summary.json/requests.json。

- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c1`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `7e01398714811cbedafe57b36e762da04ff7dcb2a8c781fd9c9d76461b0ef040`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c1-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c2`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `aa61597cba9c65370217bae35637340c35704d7981dbbb0d871cad7db6252e42`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c2-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c4`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `59ea707dce255fff770f99b1fbeda94ed7a03f47bcde86f10466949df979778a`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c4-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c8`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `9ee73d31efb3beb286ae4e0ae79fc03429b25621f5d2ed699859aa4f944de352`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-whole-c8-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c1`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `719017239c5ce4d69dd11e15916c1fbcdf503789956c593e8ab97255d408126e`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c1-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c2`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `ccc372d814c382a5f2a7a79e29739683b39bf18c9517a7bffbfbecd5e204a8ba`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c2-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c4`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `a41a41c2b330c741da6f5ef5f80ed9ecb26fc6b22b357a53dc311c80188e5214`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c4-sim`。
- `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c8`
  env `bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3`；config `70ad66ee73bef2f80471da3e26ac57fe89c2660176fff028fade599ec1c5f2f6`；
  模拟 `/private/var/folders/b8/qhx6fc396qq1z83dhr69xqdw0000gn/T/prism-release-rwj92p5w/repo/runs/.reproduce/181fa275bc7b4421b8f00cf4ec8cec40/serve/runs/20261019-p3-serve-75b53ee4-stream-c8-sim`。
