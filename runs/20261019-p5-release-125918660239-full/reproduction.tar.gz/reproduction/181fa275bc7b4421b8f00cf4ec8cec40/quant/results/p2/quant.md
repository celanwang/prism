# P2-T1 权重量化报告草稿（待规划层终审）

CPU 实测：Apple M4 Max；设备 CPU；单线程。
预热 3 次，重复 30 次；两个相反顺序批次；单位 ms。
实现通过不表示精度可接受；本任务不设精度合格阈值。

## 精度与精确载荷簿记

token 一致率只计生成后缀；首分歧为生成后缀零基索引。logits 对比 reference_logits.npz。

| 方案 | within 一致率/首分歧 | rollover 一致率/首分歧 | logits max/MSE | 随机一致率 | 模型 bytes | 压缩比 |
| --- | --- | --- | --- | --- | --- | --- |
| fp32 | 1.000000/None | 1.000000/None | 9.53674316e-06/1.94212968e-12 | 1.000000 | 1914880 | 1.000000× |
| int8 | 1.000000/None | 1.000000/None | 0.0651092529/0.000232012259 | 1.000000 | 744448 | 2.572215× |
| int4 | 0.968750/24 | 0.562500/9 | 0.57213974/0.0251380081 | 0.562500 | 587776 | 3.257840× |

随机 prompts：种子 42，8 个，长度 12，生成 16；对比 cached fp32。

精确簿记（包含 padding 和 fp32 scales，零点为隐式 0；不计 Python 元数据）：

```json
{
  "fp32": {
    "total_bytes": 1914880,
    "compression_ratio": 1.0
  },
  "int8": {
    "fp32_baseline_bytes": 1914880,
    "linear_fp32_bytes": 1572864,
    "retained_fp32_bytes": 342016,
    "integer_bytes_including_padding": 393216,
    "scale_bytes": 9216,
    "zero_point_bytes": 0,
    "total_bytes": 744448,
    "compression_ratio": 2.5722145804676755,
    "linear_compression_ratio": 3.9083969465648853
  },
  "int4": {
    "fp32_baseline_bytes": 1914880,
    "linear_fp32_bytes": 1572864,
    "retained_fp32_bytes": 342016,
    "integer_bytes_including_padding": 196608,
    "scale_bytes": 49152,
    "zero_point_bytes": 0,
    "total_bytes": 587776,
    "compression_ratio": 3.2578397212543555,
    "linear_compression_ratio": 6.4
  }
}
```

## 时延与峰值旁证

prefill 为整段提示；decode 为固定 fp32 前缀下 32 个 cached 步骤，排除 prefill。
每条记录含完整 config hash、env 指纹及原始 samples。

| batch | 方案 | 阶段 | 成分 | p50 | p95 | p99 | traced peak bytes | RSS bytes | config hash | env 指纹 | run |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | fp32 | prefill | full | 0.890521 | 1.091300 | 1.285920 | 251932 | 106758144 | 0376384da6c2830e3e4a49145bcf8bf60cdddb094bd8eee5b33b4bcb2e2eb337 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-fp32-prefill-full |
| 1 | fp32 | prefill | dequantize | 0.000625 | 0.000731 | 0.001016 | 392 | 117899264 | 0885ab7f1625ff40426efdf4767c41a41602f33e351261f65c0178125fed1c19 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-fp32-prefill-dequantize |
| 1 | fp32 | prefill | matmul_bias | 0.163687 | 0.188598 | 0.286336 | 117560 | 117899264 | 0f1d22a99df935dd3d24aed70a7d470660c51b50e04aaef678abd02366ba1bfa | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-fp32-prefill-matmul_bias |
| 1 | fp32 | decode | full | 17.825375 | 19.512046 | 20.204758 | 221846 | 118177792 | eb0eaa73c6bd5ac9fa7958b9e8ad8a6382208a826978190ea4243617954d8f25 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-fp32-decode-full |
| 1 | fp32 | decode | dequantize | 0.000480 | 0.000629 | 0.000667 | 392 | 118177792 | 05d18de827722fcf7d5f00a480f019a5b6942bdf3f8e2eb864b8aaef2e981c7d | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-fp32-decode-dequantize |
| 1 | fp32 | decode | matmul_bias | 1.099959 | 1.224487 | 1.276444 | 6456 | 118177792 | edd5fa04cabae094454f86c5b598d2b4ad07f7dd03438189697386cf73b4fe59 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-fp32-decode-matmul_bias |
| 1 | int8 | prefill | full | 1.178500 | 1.437925 | 1.589490 | 701748 | 118177792 | f8c57153af0bc07985fdb281f79e4e1e36a01f037f27c6ac19fe69e4e1616bec | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int8-prefill-full |
| 1 | int8 | prefill | dequantize | 0.181750 | 0.284198 | 0.361611 | 558760 | 118194176 | ade1e4afcc51853dfe5b81784afec2c9d4c0968399342972dbd9c835a34673c1 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int8-prefill-dequantize |
| 1 | int8 | prefill | matmul_bias | 0.160021 | 0.187973 | 0.199237 | 117560 | 118194176 | 2a756a3204e5333dc5cd7fe513d86c33e3c4b2b72a6ea901e3d11cae2bfdeecb | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int8-prefill-matmul_bias |
| 1 | int8 | decode | full | 26.434896 | 30.814367 | 33.782405 | 774200 | 119947264 | 34a235933814979b96c8e1f8d5000aab152ade7f509ec780b7d3285f8a993152 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int8-decode-full |
| 1 | int8 | decode | dequantize | 7.394687 | 8.187111 | 8.544705 | 558760 | 119947264 | c7ed08d69b9b3a1b2057b9bcc80d69f2ac95b82f10287d08cdee911a5facda58 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int8-decode-dequantize |
| 1 | int8 | decode | matmul_bias | 1.130729 | 1.286829 | 1.461486 | 6456 | 119947264 | da33af3321331b15a425fd60c2f9fea5025b5d51d632f0c182401031800c633c | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int8-decode-matmul_bias |
| 1 | int4 | prefill | full | 4.130104 | 4.671875 | 4.774386 | 1061216 | 119947264 | 8dd095c7fb4f23a0f330602e574235b24001a4c174c5bb57474f4db1c7cfbeff | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int4-prefill-full |
| 1 | int4 | prefill | dequantize | 3.207667 | 3.374070 | 3.464849 | 918576 | 119947264 | 3cdc2df97c23922246b50f9c04a47c29fb7d7a18900cdab81078b547180b4afc | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int4-prefill-dequantize |
| 1 | int4 | prefill | matmul_bias | 0.149417 | 0.180963 | 0.206231 | 117560 | 119947264 | 45d8be1b161d16ae0786a8b7208e7e32dedff709788927a027bc7cdf189ad8b7 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int4-prefill-matmul_bias |
| 1 | int4 | decode | full | 119.147520 | 126.293504 | 128.533037 | 1133821 | 120012800 | 0793bf9c0be34fc47d43e40b12dd1e6823a19c2384fc7e5a173ecd6926de68f1 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int4-decode-full |
| 1 | int4 | decode | dequantize | 99.537292 | 105.807587 | 106.704851 | 918576 | 120012800 | 4b25de89f8f76b3a0c81416f0cf234ef09cca928148df9b60b43849205c2c3b0 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int4-decode-dequantize |
| 1 | int4 | decode | matmul_bias | 1.095313 | 1.272316 | 1.324774 | 6456 | 120012800 | 94881c9fef1fccac04a454d42ad9ad632052c4a92c99c561c4ac55a6590842e3 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b1-int4-decode-matmul_bias |
| 2 | int4 | prefill | full | 4.316000 | 4.910229 | 5.155949 | 1061165 | 120012800 | ec67bfc029d16b556007659b2fd6e956d3c500c5e4f35f2b2b5916a380f5bcce | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int4-prefill-full |
| 2 | int4 | prefill | dequantize | 3.110812 | 3.397462 | 3.528583 | 918576 | 120029184 | 5a2f64fe8cec57785432151ca8a35e2798d665d63f60b753e24d827b6b943c60 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int4-prefill-dequantize |
| 2 | int4 | prefill | matmul_bias | 0.140667 | 0.162348 | 0.173672 | 117560 | 120029184 | 6009a4559cfa2b78ab89c201c1060ecacbc263126e50cd286a0f6774cc3ee6c4 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int4-prefill-matmul_bias |
| 2 | int4 | decode | full | 119.658333 | 123.615511 | 124.531158 | 1133821 | 121110528 | d517d58bdde8f1ef80569499bea3444c340dd09846988b0dec0d615c8066f39e | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int4-decode-full |
| 2 | int4 | decode | dequantize | 98.372459 | 101.658161 | 103.687241 | 918576 | 121372672 | f9dc8be8751404ab5ccf21ff0c4a23d2e27f84b29b606d23d40b8ea02902b749 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int4-decode-dequantize |
| 2 | int4 | decode | matmul_bias | 1.143292 | 1.197667 | 1.209053 | 6456 | 121372672 | b5c6ccbdae592e7f69fb4ea266f2ea89ea43844a435a9c823ac86abb2ae743d3 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int4-decode-matmul_bias |
| 2 | int8 | prefill | full | 1.000771 | 1.061562 | 1.180104 | 701442 | 121372672 | 62ff91fe7c563bdfca49c53961e166d37b3b6b5c57a09cd326c38780b08073a9 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int8-prefill-full |
| 2 | int8 | prefill | dequantize | 0.217562 | 0.256142 | 0.314221 | 558760 | 121389056 | 4cc73777f7a22a25859165a2c6bb8af89bbf72f7207e78a90e8febbf8f795ede | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int8-prefill-dequantize |
| 2 | int8 | prefill | matmul_bias | 0.158542 | 0.187504 | 0.194425 | 117560 | 121389056 | a0f3d9171a81b3c0e189ff87e73d35f2d0f68d930014547ba05e753265d9da64 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int8-prefill-matmul_bias |
| 2 | int8 | decode | full | 24.383791 | 25.479813 | 26.273929 | 774149 | 121520128 | 245d434e3458af7e88d662339e09962dcf521fe6ae9be308055f32fe5a7bd282 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int8-decode-full |
| 2 | int8 | decode | dequantize | 7.082104 | 7.849772 | 7.996397 | 558760 | 121520128 | 933ce9b043d2f2492130b5039ca661ed29db6352efd35db2eae1b1c0b22d0b72 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int8-decode-dequantize |
| 2 | int8 | decode | matmul_bias | 1.119584 | 1.179194 | 1.201210 | 6456 | 121520128 | a37c533bad3f1f5bccf9b84a355ec1e10b5fb22ee27d053f3c3642d037262502 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-int8-decode-matmul_bias |
| 2 | fp32 | prefill | full | 0.863333 | 1.080840 | 1.179213 | 250879 | 121520128 | 4bb35a2a2571a1ff1c1884f59bbd6e489b9e64ade8a4fa6a5b75adc60fb0cf34 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-fp32-prefill-full |
| 2 | fp32 | prefill | dequantize | 0.000417 | 0.000523 | 0.000571 | 392 | 121520128 | be7960cdbc841521e6bdd944e85e2215f05b5a3e562c043d2961b56bc9f432a5 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-fp32-prefill-dequantize |
| 2 | fp32 | prefill | matmul_bias | 0.164500 | 0.185550 | 0.198593 | 117560 | 121520128 | e3c9f5334f8209c33812c26f200d33d5be4a5a2dd87d9a646a4bcff36f2f6b74 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-fp32-prefill-matmul_bias |
| 2 | fp32 | decode | full | 17.368875 | 17.804319 | 18.044126 | 221693 | 121634816 | 791930d21446cd6d0d5f8797ae91406c7f53b9c5330732204f5bf8de7427ab5c | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-fp32-decode-full |
| 2 | fp32 | decode | dequantize | 0.000458 | 0.000565 | 0.000643 | 392 | 121634816 | 67703d1e20df995c4ce986c9cfd17b7975d8c2564e7e242db406da1b4b8178d5 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-fp32-decode-dequantize |
| 2 | fp32 | decode | matmul_bias | 1.104020 | 1.180369 | 1.223274 | 6456 | 121634816 | 15de8993c10ff0e03aca4045e034b707f9ad309de8034f0603fc32ddf3ae0a27 | bddd54542eebe6920420c857c2911fde714098898a8c2a68366c44dc6b6fade3 | runs/20261019-p2-quant-130043661718-b2-fp32-decode-matmul_bias |

## 反量化与矩阵乘占比（独立探针估算）

来自实际 Linear 输入的重放；分母为完整回路 mean。独立测量并不保证相加为 100%，matmul 含 bias，输出头仍属 fp32 且不计入此 Linear 探针。

| batch | 方案 | 阶段 | 反量化/full mean | matmul+bias/full mean |
| --- | --- | --- | --- | --- |
| 1 | fp32 | prefill | 0 (无反量化) | 18.23% |
| 1 | fp32 | decode | 0 (无反量化) | 6.17% |
| 1 | int8 | prefill | 16.40% | 13.61% |
| 1 | int8 | decode | 27.47% | 4.33% |
| 1 | int4 | prefill | 75.99% | 3.59% |
| 1 | int4 | decode | 83.70% | 0.94% |
| 2 | int4 | prefill | 71.75% | 3.25% |
| 2 | int4 | decode | 82.20% | 0.96% |
| 2 | int8 | prefill | 21.89% | 15.94% |
| 2 | int8 | decode | 27.99% | 4.59% |
| 2 | fp32 | prefill | 0 (无反量化) | 18.73% |
| 2 | fp32 | decode | 0 (无反量化) | 6.44% |

## T4 经验阈值

阈值 0.092584 ms，来源 results/p0/calibration.md；低于该阈值的差异不作为收益证据。超过阈值不自动证明显著性。

```json
[
  {
    "batch": 1,
    "phase": "prefill",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -0.287979,
    "p50_speedup": 0.7556392684086841,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 1,
    "phase": "prefill",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -3.239584,
    "p50_speedup": 0.2156169414115309,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 1,
    "phase": "decode",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -8.609521,
    "p50_speedup": 0.6743122802525874,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 1,
    "phase": "decode",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -101.3221455,
    "p50_speedup": 0.1496076034582692,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "prefill",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -0.1374375000000001,
    "p50_speedup": 0.862668382676956,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "prefill",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -3.4526669999999995,
    "p50_speedup": 0.2000309082447975,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "decode",
    "scheme": "int8",
    "fp32_minus_quant_p50_ms": -7.0149159999999995,
    "p50_speedup": 0.7123123307610372,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  },
  {
    "batch": 2,
    "phase": "decode",
    "scheme": "int4",
    "fp32_minus_quant_p50_ms": -102.2894585,
    "p50_speedup": 0.14515391023726737,
    "T4": "超过 T4 经验参照；不自动证明显著性"
  }
]
```

## 实现、诊断和边界

0.5M small model, CPU, fp32 activations/KV/embeddings/tied head; weight-only. Dequantize on every Linear, then fp32 matmul: no native integer MAC acceleration. No accuracy acceptance threshold. Implementation passed does not mean acceptable accuracy. Decode uses a fixed fp32 teacher-forced continuation and immutable prefill cache, no rollover; full decoding includes K/V concatenations. Components replay captured actual Linear inputs; dequantize and matmul+bias are separately measured probes, not additive causal attribution. Persistent payload ledger excludes Python metadata and transient buffers; tied head counted once. All comparison models and probe buffers coexist; tracemalloc peaks are incremental, miss native allocations; RSS is process lifetime high-water mark, neither proves model compression. Counterbalanced single-process orders, no confidence intervals. T4 floor is a historical heuristic.

INT8 每输出通道 [-127,127]；INT4 按输入列分组 [-7,7]，真 nibble 打包，低 nibble 在先；fp32 scales，ties-to-even，尾组补 0。embedding 与共享头保留 fp32。
逐层权重误差、随机逐用例结果、cached/非 cached 的 teacher-forced 前缀定位见首个 run 的 comparison.json。

复现：`uv run --locked python scripts/quant_bench.py`；`--check` 校验并执行完整配方，仅打印 JSON，不写盘。
